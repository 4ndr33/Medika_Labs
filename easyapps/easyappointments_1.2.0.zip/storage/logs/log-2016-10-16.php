<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-10-16 13:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Users\alext\Dev\easyappointments\src\application\models\Roles_model.php 47
ERROR - 2016-10-16 13:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Users\alext\Dev\easyappointments\src\application\models\Roles_model.php 47
ERROR - 2016-10-16 13:54:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Users\alext\Dev\easyappointments\src\application\models\Roles_model.php 47
ERROR - 2016-10-16 19:48:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Users\alext\Dev\easyappointments\src\application\models\Roles_model.php 47
ERROR - 2016-10-16 20:35:42 --> Query error: Table 'easyappointments.ea_roles' doesn't exist - Invalid query: SELECT *
FROM `ea_roles`
WHERE `slug` = 'admin'
